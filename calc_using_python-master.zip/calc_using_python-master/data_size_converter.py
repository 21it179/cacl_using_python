class DataSizeConverter:
    def bits_to_bytes(self, bits):
        return bits / 8

    def bytes_to_kilobytes(self, bytes):
        return bytes / 1024

    def kilobytes_to_megabytes(self, kilobytes):
        return kilobytes / 1024
